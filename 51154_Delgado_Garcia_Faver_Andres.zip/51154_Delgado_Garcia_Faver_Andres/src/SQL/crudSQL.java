package SQL;

import java.sql.Connection;
import java.sql.ResultSet;

import javax.naming.spi.DirStateFactory.Result;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

import RentaCarGUI.frmMostrar;
import main.Alquiler;
import main.Clientes;
import main.Vehiculos;


public class crudSQL extends conexion {

	java.sql.Statement st;
	ResultSet rs;
	Clientes cli = new Clientes();
	Vehiculos veh = new Vehiculos();
	Alquiler alq = new Alquiler();

	public void insertar(String documento, String nombres, String apellidos, String telefono, String direccion) {
		try {
			Connection conexion = conectar();
			st = conexion.createStatement();
			String sql = "INSERT INTO \"Clientes\"(documento, nombres, apellidos, direccion, telefono)" + " VALUES ('"
					+ documento + "' , '" + nombres + "' , '" + apellidos + "' , '" + telefono + "', '" + direccion
					+ "')";
			st.execute(sql);
			st.close();
			conexion.close();
			JOptionPane.showMessageDialog(null, "Registro Existoso", "Mensaje", JOptionPane.INFORMATION_MESSAGE);
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, "Registro Fallido" + e, "Mensaje", JOptionPane.ERROR_MESSAGE);
		}

	}

	public void insertarVe(String Marca, String linea, String placa, String Estado) {
		try {
			Connection conexion = conectar();
			st = conexion.createStatement();
			String sql = "INSERT INTO \"Vehiculos\"(Marca, linea, placa, Estado)" + " VALUES ('" + Marca + "' , '"
					+ linea + "' , '" + placa + "' , '" + Estado + "')";
			st.execute(sql);
			st.close();
			conexion.close();
			JOptionPane.showMessageDialog(null, "Registro Existoso", "Mensaje", JOptionPane.INFORMATION_MESSAGE);
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, "Registro Fallido" + e, "Mensaje", JOptionPane.ERROR_MESSAGE);
		}

	}

	public void insertarAl(String documento, String placa, String fecha, String dias) {
		try {
			Connection conexion = conectar();
			st = conexion.createStatement();
			String sql = "INSERT INTO \"Alquiler\"(documento, placa, fecha, dias)" + " VALUES ('" + documento + "' , '"
					+ placa + "' , '" + fecha + "' , '" + dias + "')";
			st.execute(sql);
			st.close();
			conexion.close();
			JOptionPane.showMessageDialog(null, "Registro Existoso", "Mensaje", JOptionPane.INFORMATION_MESSAGE);
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, "Registro Fallido" + e, "Mensaje", JOptionPane.ERROR_MESSAGE);
		}

	}
	
	public void mostrar(String documento ) {
		try {
			Connection conexion = conectar();
			st = conexion.createStatement();
			String sql = "SELECT * FROM \"Clientes\" where documento='"+documento+"';";
			rs = st.executeQuery(sql);
			if(rs.next()) {
				cli.setDocumento(rs.getString("documento"));
				cli.setNombres(rs.getString("nombres"));
				cli.setApellidos(rs.getString("apellidos"));
				cli.setDireccion(rs.getString("direccion"));
				cli.setTelefono(rs.getString("telefono"));
			}else {
				cli.setDocumento("");
				cli.setNombres("");
				cli.setApellidos("");
				cli.setDireccion("");
				cli.setTelefono("");
				JOptionPane.showMessageDialog(null,"No Se Encontro Registro" , "Sin Registro" , JOptionPane.INFORMATION_MESSAGE);
			}
			st.close();
			conexion.close();
		}catch (Exception e) {
			JOptionPane.showMessageDialog(null,"Error En El Sistema De Busqueda" , "Error Busqueda" , JOptionPane.ERROR_MESSAGE);
		}
	}
	
	public void mostrarVe(String placa) {
		try {
			Connection conexion = conectar();
			st = conexion.createStatement();
			String sql = "SELECT * FROM \"Vehiculos\" where placa='"+placa+"';";
			rs = st.executeQuery(sql);
			if(rs.next()) {
				veh.setPlaca(rs.getString("placa"));
				veh.setMarca(rs.getString("marca"));
				veh.setLinea(rs.getString("linea"));
				veh.setEstado(rs.getString("estado"));
			}else {
				veh.setPlaca("");
				veh.setMarca("");
				veh.setLinea("");
				veh.setEstado("");
				JOptionPane.showMessageDialog(null,"No Se Encontro Registro" , "Sin Registro" , JOptionPane.INFORMATION_MESSAGE);
			}
			st.close();
			conexion.close();
		}catch (Exception e) {
			JOptionPane.showMessageDialog(null,"Error En El Sistema De Busqueda" , "Error Busqueda" , JOptionPane.ERROR_MESSAGE);
		}
	}
	
	public void mostrarAl(String documento) {
		try {
			Connection conexion = conectar();
			st = conexion.createStatement();
			String sql = "SELECT * FROM \"Alquiler\" where documento='"+documento+"';";
			rs = st.executeQuery(sql);
			if(rs.next()) {
				alq.setDocumento(rs.getString("documento"));
				alq.setPlaca(rs.getString("placa"));
				alq.setFecha(rs.getString("fecha"));
				alq.setDias(rs.getString("dias"));
			}else {
				alq.setDocumento("");
				alq.setPlaca("");
				alq.setFecha("");
				alq.setDias("");
				JOptionPane.showMessageDialog(null,"No Se Encontro Registro" , "Sin Registro" , JOptionPane.INFORMATION_MESSAGE);
			}
			st.close();
			conexion.close();
		}catch (Exception e) {
			JOptionPane.showMessageDialog(null,"Error En El Sistema De Busqueda" , "Error Busqueda" , JOptionPane.ERROR_MESSAGE);
		}
	}
	
	public void mostrarTo(String documento) {
		try {
			Connection conexion = conectar();
			st = conexion.createStatement();
			String sql = "SELECT * FROM \"Alquiler\" where documento='"+documento+"';";
			rs = st.executeQuery(sql);
			if(rs.next()) {
				alq.setDocumento(rs.getString("documento"));
				alq.setPlaca(rs.getString("placa"));
				alq.setFecha(rs.getString("fecha"));
				alq.setDias(rs.getString("dias"));
			}else {
				alq.setDocumento("");
				alq.setPlaca("");
				alq.setFecha("");
				alq.setDias("");
				JOptionPane.showMessageDialog(null,"No Se Encontro Registro" , "Sin Registro" , JOptionPane.INFORMATION_MESSAGE);
			}
			st.close();
			conexion.close();
		}catch (Exception e) {
			JOptionPane.showMessageDialog(null,"Error En El Sistema De Busqueda" , "Error Busqueda" , JOptionPane.ERROR_MESSAGE);
		}
	}

}
