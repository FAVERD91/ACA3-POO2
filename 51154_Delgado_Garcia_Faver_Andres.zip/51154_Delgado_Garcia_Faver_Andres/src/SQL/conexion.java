package SQL;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.swing.JOptionPane;

public class conexion {

	Connection con;
	String url = "jdbc:postgresql://localhost:5432/RentaCar";
	private final String user = "postgres";
	private final String password = "Cun123456";

	public Connection conectar() {
		try {
			Class.forName("org.postgresql.Driver");
			con = DriverManager.getConnection(url, user, password);
			JOptionPane.showMessageDialog(null,"Conexion Exitosa", "conexion", JOptionPane.INFORMATION_MESSAGE);
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null,"Conexion Fallida" + e, "conexion", JOptionPane.ERROR_MESSAGE);
		}
		return con;
	}

	public void cerrar() {
		try {
			con.close();
			JOptionPane.showMessageDialog(null, "Desconexion Exitosa", "desconexion", JOptionPane.INFORMATION_MESSAGE);
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, "Desconexion Fallida" + e, "desconexion", JOptionPane.ERROR_MESSAGE);
		}
	}
	
	/*public int ejecutarSQL(String strejecutarSQL) {
		try {
			PreparedStatement pstm = con.prepareStatement(strejecutarSQL);
			pstm.execute();
			return 1;
		}catch (SQLException e) {
			JOptionPane.showMessageDialog(null,e);
			return 0;
		}
		
	}*/
}

