package main;

public class Vehiculos {

	private static String placa, marca, linea, estado;

	public String getPlaca() {
		return placa;
	}

	public void setPlaca(String placa) {
		Vehiculos.placa = placa;
	}

	public String getMarca() {
		return marca;
	}

	public void setMarca(String marca) {
		Vehiculos.marca = marca;
	}

	public String getLinea() {
		return linea;
	}

	public void setLinea(String linea) {
		Vehiculos.linea = linea;
	}

	public String getEstado() {
		return estado;
	}

	public void setEstado(String estado) {
		Vehiculos.estado = estado;
	}

}
