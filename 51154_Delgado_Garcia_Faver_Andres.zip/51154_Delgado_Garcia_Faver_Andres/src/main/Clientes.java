package main;

public class Clientes {

	public String getDocumento() {
		return documento;
	}

	public void setDocumento(String string) {
		this.documento = string;
	}

	public String getTelefono() {
		return telefono;
	}

	public void setTelefono(String string) {
		this.telefono = string;
	}

	public String getNombres() {
		return nombres;
	}

	public void setNombres(String nombres) {
		this.nombres = nombres;
	}

	public String getApellidos() {
		return apellidos;
	}

	public void setApellidos(String apellidos) {
		this.apellidos = apellidos;
	}

	public String getDireccion() {
		return direccion;
	}

	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}

	String documento;
	private static String telefono;
	private static String nombres, apellidos, direccion;

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
