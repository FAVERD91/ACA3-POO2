package main;

public class Alquiler {

	private static String placa, fecha, dias;
	private static String documento;

	public final String getPlaca() {
		return placa;
	}

	public final void setPlaca(String placa) {
		Alquiler.placa = placa;
	}

	public final String getFecha() {
		return fecha;
	}

	public final void setFecha(String fecha) {
		Alquiler.fecha = fecha;
	}

	public final String getDias() {
		return dias;
	}

	public final void setDias(String dias) {
		Alquiler.dias = dias;
	}

	public final String getDocumento() {
		return documento;
	}

	public final void setDocumento(String documento) {
		Alquiler.documento = documento;
	}

}
