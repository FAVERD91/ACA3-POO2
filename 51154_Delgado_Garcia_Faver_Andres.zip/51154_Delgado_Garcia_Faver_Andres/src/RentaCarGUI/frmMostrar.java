package RentaCarGUI;

import java.awt.EventQueue;

import javax.swing.JInternalFrame;
import javax.swing.JTable;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableModel;

import org.w3c.dom.Document;

import SQL.crudSQL;
import main.Clientes;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JScrollPane;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JTextField;

public class frmMostrar extends JInternalFrame {
	private JTextField documentoV;
	private JTextField nombres;
	private JTextField apelldios;
	private JTextField direccion;
	private JTextField telefono;
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					frmMostrar frame = new frmMostrar();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	


	/**
	 * Create the frame.
	 */
	public frmMostrar() {
		setClosable(true);
		setFrameIcon(new ImageIcon(frmMostrar.class.getResource("/iconos16/clasificacion.png")));
		setTitle("Clientes Registrados");
		setBounds(100, 100, 693, 420);
		getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Clientes Registrados");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblNewLabel.setBounds(245, 11, 183, 14);
		getContentPane().add(lblNewLabel);
		
		documentoV = new JTextField();
		documentoV.setBounds(342, 54, 108, 20);
		getContentPane().add(documentoV);
		documentoV.setColumns(10);
		
		JLabel lblDocumento = new JLabel("Documento");
		lblDocumento.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblDocumento.setBounds(229, 57, 89, 14);
		getContentPane().add(lblDocumento);
		
		crudSQL objcrud = new crudSQL();
		Clientes cli = new Clientes();
		
		JButton btnConsultar = new JButton("Consultar");
		btnConsultar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				objcrud.mostrar(documentoV.getText());
				nombres.setText(cli.getNombres());
				apelldios.setText(cli.getApellidos());
				direccion.setText(cli.getDireccion());
				telefono.setText(cli.getTelefono());
			}
		});
		btnConsultar.setBounds(286, 85, 89, 23);
		getContentPane().add(btnConsultar);
		
		nombres = new JTextField();
		nombres.setBounds(342, 157, 108, 20);
		getContentPane().add(nombres);
		nombres.setColumns(10);
		
		apelldios = new JTextField();
		apelldios.setColumns(10);
		apelldios.setBounds(342, 191, 108, 20);
		getContentPane().add(apelldios);
		
		direccion = new JTextField();
		direccion.setColumns(10);
		direccion.setBounds(342, 222, 108, 20);
		getContentPane().add(direccion);
		
		telefono = new JTextField();
		telefono.setColumns(10);
		telefono.setBounds(342, 254, 108, 20);
		getContentPane().add(telefono);
		
		JLabel lblNombres = new JLabel("Nombres");
		lblNombres.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblNombres.setBounds(229, 160, 89, 14);
		getContentPane().add(lblNombres);
		
		JLabel lblApellidos = new JLabel("Apellidos");
		lblApellidos.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblApellidos.setBounds(229, 194, 89, 14);
		getContentPane().add(lblApellidos);
		
		JLabel lblDireccion = new JLabel("Direccion");
		lblDireccion.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblDireccion.setBounds(229, 225, 89, 14);
		getContentPane().add(lblDireccion);
		
		JLabel lblTelefono = new JLabel("Telefono");
		lblTelefono.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblTelefono.setBounds(229, 257, 89, 14);
		getContentPane().add(lblTelefono);
		
	
		
	}
}
