package RentaCarGUI;

import java.awt.EventQueue;

import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.ImageIcon;
import javax.swing.JTextArea;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import SQL.crudSQL;
import main.Vehiculos;

import javax.swing.JScrollPane;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.util.Vector;
import java.awt.event.ActionEvent;

public class frmMostrarveh extends JInternalFrame {
	protected static final String[] celda = null;
	DefaultTableModel model;
	private JTextField placaV;
	private JTextField marca;
	private JTextField linea;
	private JTextField estado;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					frmMostrarveh frame = new frmMostrarveh();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public frmMostrarveh() {
		setClosable(true);
		setFrameIcon(new ImageIcon(frmMostrarveh.class.getResource("/iconos16/car.png")));
		setTitle("Vehiculos Registrado");
		setBounds(100, 100, 987, 387);
		getContentPane().setLayout(null);
		
		JLabel lblVehiculosRegistrados = new JLabel("Vehiculos Registrados");
		lblVehiculosRegistrados.setHorizontalAlignment(SwingConstants.CENTER);
		lblVehiculosRegistrados.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblVehiculosRegistrados.setBounds(383, 26, 183, 14);
		getContentPane().add(lblVehiculosRegistrados);
		
		placaV = new JTextField();
		placaV.setBounds(401, 65, 142, 20);
		getContentPane().add(placaV);
		placaV.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("Placa");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblNewLabel.setBounds(342, 66, 61, 14);
		getContentPane().add(lblNewLabel);
		
		crudSQL objcrud = new crudSQL();
		Vehiculos veh = new Vehiculos();
		
		JButton btnBuscar = new JButton("Buscar");
		btnBuscar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				objcrud.mostrarVe(placaV.getText());
				marca.setText(veh.getMarca());
				linea.setText(veh.getLinea());
				estado.setText(veh.getEstado());
				
			}
		});
		btnBuscar.setBounds(557, 64, 89, 23);
		getContentPane().add(btnBuscar);
		
		marca = new JTextField();
		marca.setColumns(10);
		marca.setBounds(472, 158, 108, 20);
		getContentPane().add(marca);
		
		linea = new JTextField();
		linea.setColumns(10);
		linea.setBounds(472, 192, 108, 20);
		getContentPane().add(linea);
		
		estado = new JTextField();
		estado.setColumns(10);
		estado.setBounds(472, 223, 108, 20);
		getContentPane().add(estado);
		
		JLabel lblMarca = new JLabel("Marca");
		lblMarca.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblMarca.setBounds(359, 161, 89, 14);
		getContentPane().add(lblMarca);
		
		JLabel lblLinea = new JLabel("Linea");
		lblLinea.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblLinea.setBounds(359, 195, 89, 14);
		getContentPane().add(lblLinea);
		
		JLabel lblEstado = new JLabel("Estado");
		lblEstado.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblEstado.setBounds(359, 226, 89, 14);
		getContentPane().add(lblEstado);

	}
}
