package RentaCarGUI;

import java.awt.EventQueue;
import SQL.conexion;
import SQL.crudSQL;

import javax.swing.JInternalFrame;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.SwingConstants;


import javax.swing.JTextField;
import java.awt.SystemColor;
import javax.swing.JTextArea;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class frmClientes extends JInternalFrame {

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					frmClientes frame = new frmClientes();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public frmClientes() {
		setClosable(true);
		setFrameIcon(new ImageIcon(frmClientes.class.getResource("/iconos16/cambiar.png")));
		setTitle("Registro Clientes");
		setBounds(100, 100, 613, 531);
		getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Registro Clientes");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("Arial", Font.BOLD, 18));
		lblNewLabel.setBounds(221, 22, 151, 44);
		getContentPane().add(lblNewLabel);
		
		JTextArea documento = new JTextArea();
		documento.setBounds(258, 122, 141, 23);
		getContentPane().add(documento);
		
		JLabel lblNewLabel_1 = new JLabel("N\u00B0 Documento");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblNewLabel_1.setBounds(93, 122, 129, 32);
		getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("Nombres");
		lblNewLabel_1_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_1.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblNewLabel_1_1.setBounds(93, 179, 129, 32);
		getContentPane().add(lblNewLabel_1_1);
		
		JTextArea nombres = new JTextArea();
		nombres.setBounds(258, 188, 141, 23);
		getContentPane().add(nombres);
		
		JLabel lblNewLabel_1_1_1 = new JLabel("Apellidos");
		lblNewLabel_1_1_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_1_1.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblNewLabel_1_1_1.setBounds(93, 238, 129, 32);
		getContentPane().add(lblNewLabel_1_1_1);
		
		JTextArea apellidos = new JTextArea();
		apellidos.setBounds(258, 247, 141, 23);
		getContentPane().add(apellidos);
		
		JLabel lblNewLabel_1_1_1_1 = new JLabel("Telefono");
		lblNewLabel_1_1_1_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_1_1_1.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblNewLabel_1_1_1_1.setBounds(93, 358, 129, 32);
		getContentPane().add(lblNewLabel_1_1_1_1);
		
		JTextArea telefono = new JTextArea();
		telefono.setBounds(258, 306, 141, 23);
		getContentPane().add(telefono);
		
		JLabel lblNewLabel_1_1_1_2 = new JLabel("Direccion");
		lblNewLabel_1_1_1_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_1_1_2.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblNewLabel_1_1_1_2.setBounds(93, 300, 129, 32);
		getContentPane().add(lblNewLabel_1_1_1_2);
		
		JTextArea direccion = new JTextArea();
		direccion.setBounds(258, 364, 186, 23);
		getContentPane().add(direccion);
		
		crudSQL objcrud = new crudSQL();
		
		JButton btnEnviar = new JButton("Enviar");
		btnEnviar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				objcrud.insertar(documento.getText(), nombres.getText(),apellidos.getText(),telefono.getText(),direccion.getText());
			}
		});
		btnEnviar.setFont(new Font("Tahoma", Font.PLAIN, 16));
		btnEnviar.setBounds(157, 425, 89, 23);
		getContentPane().add(btnEnviar);
		
		JButton btnLimpiar = new JButton("Limpiar");
		btnLimpiar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				documento.setText(null);
				nombres.setText(null);
				apellidos.setText(null);
				telefono.setText(null);
				direccion.setText(null);
			}
		});
		btnLimpiar.setFont(new Font("Tahoma", Font.PLAIN, 16));
		btnLimpiar.setBounds(355, 427, 89, 23);
		getContentPane().add(btnLimpiar);

	}
}
