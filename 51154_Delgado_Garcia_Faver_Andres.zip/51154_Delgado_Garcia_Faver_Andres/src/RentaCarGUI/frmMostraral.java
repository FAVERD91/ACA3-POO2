package RentaCarGUI;

import java.awt.EventQueue;

import javax.swing.JInternalFrame;
import javax.swing.ImageIcon;
import javax.swing.JTextField;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JButton;
import javax.swing.JSeparator;
import java.awt.Color;
import java.awt.SystemColor;
import javax.swing.SwingConstants;

import SQL.crudSQL;
import main.Alquiler;
import main.Clientes;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class frmMostraral extends JInternalFrame {
	private JTextField documentoV;
	private JTextField placa;
	private JTextField fecha;
	private JTextField dias;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					frmMostraral frame = new frmMostraral();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public frmMostraral() {
		getContentPane().setBackground(SystemColor.control);
		setFrameIcon(new ImageIcon(frmMostraral.class.getResource("/iconos16/consulta.png")));
		setClosable(true);
		setTitle("Alquileres Realizados");
		setBounds(100, 100, 783, 392);
		getContentPane().setLayout(null);
		
		documentoV = new JTextField();
		documentoV.setColumns(10);
		documentoV.setBounds(333, 82, 142, 20);
		getContentPane().add(documentoV);
		
		JLabel lblDocumento = new JLabel("Documento");
		lblDocumento.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblDocumento.setBounds(234, 83, 89, 14);
		getContentPane().add(lblDocumento);
		
		crudSQL objcrud = new crudSQL();
		Alquiler alq = new Alquiler();
		
		JButton btnBuscar = new JButton("Buscar");
		btnBuscar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				objcrud.mostrarAl(documentoV.getText());
				placa.setText(alq.getPlaca());
				fecha.setText(alq.getFecha());
				dias.setText(alq.getDias());
			}
		});
		btnBuscar.setBounds(485, 81, 89, 23);
		getContentPane().add(btnBuscar);
		
		placa = new JTextField();
		placa.setColumns(10);
		placa.setBounds(385, 199, 108, 20);
		getContentPane().add(placa);
		
		fecha = new JTextField();
		fecha.setColumns(10);
		fecha.setBounds(385, 233, 108, 20);
		getContentPane().add(fecha);
		
		dias = new JTextField();
		dias.setColumns(10);
		dias.setBounds(385, 264, 108, 20);
		getContentPane().add(dias);
		
		JLabel lblMarca = new JLabel("Placa");
		lblMarca.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblMarca.setBounds(272, 202, 89, 14);
		getContentPane().add(lblMarca);
		
		JLabel lblLinea = new JLabel("Fecha");
		lblLinea.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblLinea.setBounds(272, 236, 89, 14);
		getContentPane().add(lblLinea);
		
		JLabel lblEstado = new JLabel("Dias");
		lblEstado.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblEstado.setBounds(272, 267, 89, 14);
		getContentPane().add(lblEstado);
		
		JSeparator separator = new JSeparator();
		separator.setBackground(SystemColor.desktop);
		separator.setBounds(10, 151, 747, 2);
		getContentPane().add(separator);
		
		JLabel lblAlquieleresRegistrados = new JLabel("Alquileres Registrados");
		lblAlquieleresRegistrados.setHorizontalAlignment(SwingConstants.CENTER);
		lblAlquieleresRegistrados.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblAlquieleresRegistrados.setBounds(317, 11, 183, 14);
		getContentPane().add(lblAlquieleresRegistrados);

	}
}
