package RentaCarGUI;

import SQL.conexion;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Frame;
import java.awt.SystemColor;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.Normalizer.Form;

import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDesktopPane;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JSeparator;
import javax.swing.JToolBar;
import javax.swing.LayoutStyle.ComponentPlacement;


public class frmPrincipal extends JFrame {
	
/**
	 * 
	 */
private static final long serialVersionUID = 1L;
private frmMostrar fm;
private frmClientes fc;
private frmVehiculos fv;
private frmAlquiler fa;
private frmMostrarveh fmv;
private frmMostraral fma;
private frmMostrarto ft;
private JDesktopPane dpPrincipal;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					frmPrincipal frame = new frmPrincipal();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	
	void dise�aGUI() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(frmPrincipal.class.getResource("/iconos16/car.png")));
		setTitle("Sistema de Gestion RentaCar");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 606, 345);
		
		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		
		JMenu mnNewMenu = new JMenu("Clientes");
		menuBar.add(mnNewMenu);
		
		JMenuItem mntmNewMenuItem = new JMenuItem("Clientes registrados");
		mntmNewMenuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cargaMostrar();
			}
		});
		mntmNewMenuItem.setIcon(new ImageIcon(frmPrincipal.class.getResource("/iconos16/cambiar.png")));
		mnNewMenu.add(mntmNewMenuItem);
		
		JSeparator separator = new JSeparator();
		mnNewMenu.add(separator);
		
		JMenuItem mntmNewMenuItem_3 = new JMenuItem("Consultar Alquiler Cliente");
		mntmNewMenuItem_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cargaAlquiler();
			}
		});
		mntmNewMenuItem_3.setIcon(new ImageIcon(frmPrincipal.class.getResource("/iconos16/consulta.png")));
		mntmNewMenuItem_3.setSelectedIcon(new ImageIcon(frmPrincipal.class.getResource("/iconos16/consulta.png")));
		mnNewMenu.add(mntmNewMenuItem_3);
		
		JMenu mnNewMenu_1 = new JMenu("Vehiculos");
		menuBar.add(mnNewMenu_1);
		
		JMenuItem mntmNewMenuItem_1 = new JMenuItem("Validar Vehiculos");
		mntmNewMenuItem_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cargaMostrarveh();
			}
		});
		mntmNewMenuItem_1.setIcon(new ImageIcon(frmPrincipal.class.getResource("/iconos16/car.png")));
		mnNewMenu_1.add(mntmNewMenuItem_1);
		
		JMenu mnNewMenu_2 = new JMenu("Alquiler");
		menuBar.add(mnNewMenu_2);
		
		JMenuItem mntmNewMenuItem_2 = new JMenuItem("Alquiler Realizados");
		mntmNewMenuItem_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cargaMostrarAlq();
			}
		});
		mntmNewMenuItem_2.setIcon(new ImageIcon(frmPrincipal.class.getResource("/iconos16/nube.png")));
		mntmNewMenuItem_2.setSelectedIcon(new ImageIcon(frmPrincipal.class.getResource("/iconos16/nube.png")));
		mnNewMenu_2.add(mntmNewMenuItem_2);
		
		JMenuItem mntmNewMenuItem_4 = new JMenuItem("Alquiler Por Cliente");
		mntmNewMenuItem_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cargaMostrarTo();
			}
		});
		mntmNewMenuItem_4.setIcon(new ImageIcon(frmPrincipal.class.getResource("/iconos16/clasificacion.png")));
		mnNewMenu_2.add(mntmNewMenuItem_4);
		
		JMenu mnSalir = new JMenu("Salir");
		mnSalir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		menuBar.add(mnSalir);
		
		JMenuItem mntmSalir = new JMenuItem("Salir");
		mntmSalir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if(JOptionPane.showConfirmDialog(null,"Esta Seguro de Salir Del Sistema" , "Salir",JOptionPane.YES_NO_OPTION)==0) {
					System.exit(0);
				}
			}
		});
		mntmSalir.setIcon(new ImageIcon(frmPrincipal.class.getResource("/iconos16/cerrar-sesion.png")));
		mnSalir.add(mntmSalir);
		
		JToolBar toolBar = new JToolBar();
		toolBar.setBackground(SystemColor.control);
		toolBar.setFloatable(false);
		
		dpPrincipal = new JDesktopPane();
		dpPrincipal.setBackground(SystemColor.activeCaption);
		GroupLayout groupLayout = new GroupLayout(getContentPane());
		groupLayout.setHorizontalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addComponent(toolBar, Alignment.TRAILING, GroupLayout.DEFAULT_SIZE, 590, Short.MAX_VALUE)
				.addComponent(dpPrincipal, GroupLayout.DEFAULT_SIZE, 590, Short.MAX_VALUE)
		);
		groupLayout.setVerticalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addComponent(toolBar, GroupLayout.PREFERRED_SIZE, 43, GroupLayout.PREFERRED_SIZE)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(dpPrincipal, GroupLayout.DEFAULT_SIZE, 247, Short.MAX_VALUE))
		);
		
		JButton btnClientes = new JButton("Clientes");
		btnClientes.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				cargaClientes();
			}
			
		});
		btnClientes.setIcon(new ImageIcon(frmPrincipal.class.getResource("/iconos32/clasificacion.png")));
		toolBar.add(btnClientes);
		
		JButton btnVehiculos = new JButton("Vehiculos");
		btnVehiculos.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				cargaVehiculos();
			}
		});
		btnVehiculos.setIcon(new ImageIcon(frmPrincipal.class.getResource("/iconos32/trafico.png")));
		toolBar.add(btnVehiculos);
		conexion con = new conexion();
		getContentPane().setLayout(groupLayout);
	}
	
	
	void cargaVehiculos() {
		if(fv==null|| fv.isClosed()){
		fv = new frmVehiculos();
		Dimension tf = fv.getSize();
		fv.setLocation((dpPrincipal.getWidth()-tf.width)/2, (dpPrincipal.getHeight()-tf.height)/2);
		dpPrincipal.add(fv);
		fv.show();
		}
	}

	/**
	 * Create the frame.
	 */
	public frmPrincipal() {
		this.setExtendedState(Frame.MAXIMIZED_BOTH);
		dise�aGUI();
	}
	
	void cargaClientes() {
		if(fc==null|| fc.isClosed()){
		fc = new frmClientes();
		Dimension tf = fc.getSize();
		fc.setLocation((dpPrincipal.getWidth()-tf.width)/2, (dpPrincipal.getHeight()-tf.height)/2);
		dpPrincipal.add(fc);
		fc.show();
		}
	}
	
	void cargaAlquiler() {
		if(fa==null|| fa.isClosed()){
		fa = new frmAlquiler();
		Dimension tf = fa.getSize();
		fa.setLocation((dpPrincipal.getWidth()-tf.width)/2, (dpPrincipal.getHeight()-tf.height)/2);
		dpPrincipal.add(fa);
		fa.show();
		}
	}
	
	void cargaMostrar() {
		if(fm==null|| fm.isClosed()){
		fm = new frmMostrar();
		Dimension tf = fm.getSize();
		fm.setLocation((dpPrincipal.getWidth()-tf.width)/2, (dpPrincipal.getHeight()-tf.height)/2);
		dpPrincipal.add(fm);
		fm.show();
		}
	}
	
	void cargaMostrarveh() {
		if(fmv==null|| fmv.isClosed()){
		fmv = new frmMostrarveh();
		Dimension tf = fmv.getSize();
		fmv.setLocation((dpPrincipal.getWidth()-tf.width)/2, (dpPrincipal.getHeight()-tf.height)/2);
		dpPrincipal.add(fmv);
		fmv.show();
		}
	}
	
	void cargaMostrarAlq() {
		if(fma==null|| fma.isClosed()){
			fma = new frmMostraral();
		Dimension tf = fma.getSize();
		fma.setLocation((dpPrincipal.getWidth()-tf.width)/2, (dpPrincipal.getHeight()-tf.height)/2);
		dpPrincipal.add(fma);
		fma.show();
		}
	}
	
	void cargaMostrarTo() {
		if(ft==null|| ft.isClosed()){
			ft = new frmMostrarto();
		Dimension tf = ft.getSize();
		ft.setLocation((dpPrincipal.getWidth()-tf.width)/2, (dpPrincipal.getHeight()-tf.height)/2);
		dpPrincipal.add(ft);
		ft.show();
		}
	}
}
