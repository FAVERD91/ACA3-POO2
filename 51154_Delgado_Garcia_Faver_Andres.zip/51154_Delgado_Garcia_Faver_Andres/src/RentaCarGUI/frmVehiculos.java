package RentaCarGUI;

import java.awt.EventQueue;

import javax.swing.JInternalFrame;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.SwingConstants;

import SQL.crudSQL;

import javax.swing.JTextField;
import javax.swing.JList;
import javax.swing.JTextArea;
import javax.swing.JSpinner;
import javax.swing.SpinnerListModel;
import javax.swing.JToggleButton;
import javax.swing.JTextPane;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class frmVehiculos extends JInternalFrame {
	private JTextField Marca;
	private JTextField linea;
	private JTextField placa;
	private JTextField Estado;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					frmVehiculos frame = new frmVehiculos();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public frmVehiculos() {
		setFrameIcon(new ImageIcon(frmVehiculos.class.getResource("/iconos16/car.png")));
		setTitle("Registro Vehiculos");
		setClosable(true);
		setBounds(100, 100, 712, 469);
		getContentPane().setLayout(null);
		
		JLabel lblRegistroVehiculos = new JLabel("Registro Vehiculos");
		lblRegistroVehiculos.setHorizontalAlignment(SwingConstants.CENTER);
		lblRegistroVehiculos.setFont(new Font("Arial", Font.BOLD, 18));
		lblRegistroVehiculos.setBounds(235, 11, 209, 44);
		getContentPane().add(lblRegistroVehiculos);
		
		JLabel lbMarca = new JLabel("Marca");
		lbMarca.setHorizontalAlignment(SwingConstants.CENTER);
		lbMarca.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lbMarca.setBounds(235, 204, 71, 14);
		getContentPane().add(lbMarca);
		
		Marca = new JTextField();
		Marca.setBounds(332, 203, 114, 20);
		getContentPane().add(Marca);
		Marca.setColumns(10);
		
		JLabel lblLinea = new JLabel("Linea");
		lblLinea.setHorizontalAlignment(SwingConstants.CENTER);
		lblLinea.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblLinea.setBounds(233, 173, 71, 14);
		getContentPane().add(lblLinea);
		
		linea = new JTextField();
		linea.setColumns(10);
		linea.setBounds(330, 172, 114, 20);
		getContentPane().add(linea);
		
		placa = new JTextField();
		placa.setColumns(10);
		placa.setBounds(330, 142, 114, 20);
		getContentPane().add(placa);
		
		JLabel lblPlaca = new JLabel("Placa");
		lblPlaca.setHorizontalAlignment(SwingConstants.CENTER);
		lblPlaca.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblPlaca.setBounds(235, 145, 71, 14);
		getContentPane().add(lblPlaca);
		
		JLabel lblEstado = new JLabel("Estado");
		lblEstado.setHorizontalAlignment(SwingConstants.CENTER);
		lblEstado.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblEstado.setBounds(235, 244, 71, 14);
		getContentPane().add(lblEstado);
		
		Estado = new JTextField();
		Estado.setColumns(10);
		Estado.setBounds(330, 243, 114, 20);
		getContentPane().add(Estado);
		
		crudSQL objcrud = new crudSQL();
		
		JButton btnRegistrar = new JButton("Registrar");
		btnRegistrar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				objcrud.insertarVe(Marca.getText(), linea.getText(),placa.getText(),Estado.getText());
			}
		});
		btnRegistrar.setBounds(215, 323, 89, 23);
		getContentPane().add(btnRegistrar);
		
		JButton btnLimpiar = new JButton("Limpiar");
		btnLimpiar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				Marca.setText(null);
				linea.setText(null);
				placa.setText(null);
				Estado.setText(null);
			}
		});
		btnLimpiar.setBounds(378, 323, 89, 23);
		getContentPane().add(btnLimpiar);
		
		

	}
}
