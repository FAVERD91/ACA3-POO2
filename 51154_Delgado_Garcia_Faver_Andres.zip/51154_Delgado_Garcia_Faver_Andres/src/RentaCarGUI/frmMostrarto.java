package RentaCarGUI;

import java.awt.EventQueue;

import javax.swing.JInternalFrame;
import javax.swing.ImageIcon;
import javax.swing.JTextField;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JButton;
import javax.swing.SwingConstants;

import SQL.crudSQL;
import main.Alquiler;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JSeparator;
import java.awt.SystemColor;

public class frmMostrarto extends JInternalFrame {
	private JTextField documentoV;
	private JTextField placa;
	private JTextField fecha;
	private JTextField dias;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					frmMostrarto frame = new frmMostrarto();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public frmMostrarto() {
		setClosable(true);
		setFrameIcon(new ImageIcon(frmMostrarto.class.getResource("/iconos16/cv.png")));
		setTitle("Consultar Informacion Alquileres Cliente");
		setBounds(100, 100, 938, 437);
		getContentPane().setLayout(null);
		
		documentoV = new JTextField();
		documentoV.setColumns(10);
		documentoV.setBounds(381, 82, 142, 20);
		getContentPane().add(documentoV);
		
		JLabel lblDocumento = new JLabel("Documento");
		lblDocumento.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblDocumento.setBounds(282, 83, 89, 14);
		getContentPane().add(lblDocumento);
		
		crudSQL objcrud = new crudSQL();
		Alquiler alq = new Alquiler();
		
		JButton btnBuscar = new JButton("Buscar");
		btnBuscar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				objcrud.mostrarAl(documentoV.getText());
				placa.setText(alq.getPlaca());
				fecha.setText(alq.getFecha());
				dias.setText(alq.getDias());
			}
		});
		btnBuscar.setBounds(533, 81, 89, 23);
		getContentPane().add(btnBuscar);
		
		placa = new JTextField();
		placa.setColumns(10);
		placa.setBounds(433, 199, 108, 20);
		getContentPane().add(placa);
		
		fecha = new JTextField();
		fecha.setColumns(10);
		fecha.setBounds(433, 233, 108, 20);
		getContentPane().add(fecha);
		
		dias = new JTextField();
		dias.setColumns(10);
		dias.setBounds(433, 264, 108, 20);
		getContentPane().add(dias);
		
		JLabel lblMarca = new JLabel("Placa");
		lblMarca.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblMarca.setBounds(320, 202, 89, 14);
		getContentPane().add(lblMarca);
		
		JLabel lblLinea = new JLabel("Fecha");
		lblLinea.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblLinea.setBounds(320, 236, 89, 14);
		getContentPane().add(lblLinea);
		
		JLabel lblEstado = new JLabel("Dias");
		lblEstado.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblEstado.setBounds(320, 267, 89, 14);
		getContentPane().add(lblEstado);
		
		JLabel lblInformacionRegistrada = new JLabel("Alquileres Registrados Clientes");
		lblInformacionRegistrada.setHorizontalAlignment(SwingConstants.CENTER);
		lblInformacionRegistrada.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblInformacionRegistrada.setBounds(304, 11, 292, 14);
		getContentPane().add(lblInformacionRegistrada);
		
		JSeparator separator = new JSeparator();
		separator.setBackground(SystemColor.desktop);
		separator.setBounds(10, 152, 902, 2);
		getContentPane().add(separator);

	}

}
