package RentaCarGUI;

import java.awt.EventQueue;

import javax.swing.JInternalFrame;
import javax.swing.ImageIcon;
import javax.swing.JTextArea;
import javax.swing.JTextPane;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.SwingConstants;

import SQL.crudSQL;

import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class frmAlquiler extends JInternalFrame {
	private JTextField documento;
	private JTextField placa;
	private JTextField fecha;
	private JTextField dias_alquiler;
	private JTextField dias;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					frmAlquiler frame = new frmAlquiler();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public frmAlquiler() {
		setClosable(true);
		setFrameIcon(new ImageIcon(frmAlquiler.class.getResource("/iconos16/cv.png")));
		setTitle("Alquiler Vehiculos");
		setBounds(100, 100, 646, 431);
		getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Registro Alquiler Vehiculos");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblNewLabel.setBounds(194, 26, 233, 37);
		getContentPane().add(lblNewLabel);
		
		JLabel lblDocumento = new JLabel("Documento");
		lblDocumento.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblDocumento.setBounds(193, 103, 88, 14);
		getContentPane().add(lblDocumento);
		
		documento = new JTextField();
		documento.setBounds(308, 102, 119, 20);
		getContentPane().add(documento);
		documento.setColumns(10);
		
		JLabel lblPlaca = new JLabel("Placa");
		lblPlaca.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblPlaca.setBounds(193, 140, 88, 14);
		getContentPane().add(lblPlaca);
		
		placa = new JTextField();
		placa.setColumns(10);
		placa.setBounds(308, 139, 119, 20);
		getContentPane().add(placa);
		
		JLabel Fecha_Alquiler = new JLabel("Fecha Alquiler");
		Fecha_Alquiler.setFont(new Font("Tahoma", Font.PLAIN, 16));
		Fecha_Alquiler.setBounds(194, 177, 100, 14);
		getContentPane().add(Fecha_Alquiler);
		
		fecha = new JTextField();
		fecha.setColumns(10);
		fecha.setBounds(308, 176, 119, 20);
		getContentPane().add(fecha);
		
		JLabel lblDiasAlquiler = new JLabel("Dias Alquiler");
		lblDiasAlquiler.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblDiasAlquiler.setBounds(193, 211, 101, 14);
		getContentPane().add(lblDiasAlquiler);
		
		dias = new JTextField();
		dias.setBounds(308, 207, 119, 20);
		getContentPane().add(dias);
		dias.setColumns(10);
		
		crudSQL objcrud = new crudSQL();
		
		JButton btnNewButton = new JButton("Registrar");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				objcrud.insertarAl(documento.getText(), placa.getText(),fecha.getText(),dias.getText());
			}
		});
		btnNewButton.setBounds(192, 290, 89, 23);
		getContentPane().add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Limpiar");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				documento.setText(null);
				placa.setText(null);
				fecha.setText(null);
				dias.setText(null);
			}
		});
		btnNewButton_1.setBounds(335, 290, 89, 23);
		getContentPane().add(btnNewButton_1);
		
		

	}

}
